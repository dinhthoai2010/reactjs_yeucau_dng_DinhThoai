export const BASE_URL = process.env.REACT_APP_BASE_URL
export const DEFAULT_AVATAR = 'https://huyhoanhotel.com/wp-content/uploads/2016/05/765-default-avatar.png'
export const DATE_TEMPLATE = 'DD/MM/YYYY';