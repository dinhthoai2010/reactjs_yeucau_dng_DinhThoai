const intState = {
  currentUser: null
}

function reducer(authState = intState, action) {
  return authState;
}

export default reducer;